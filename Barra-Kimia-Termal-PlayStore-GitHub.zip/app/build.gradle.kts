plugins {
    id("com.android.application")
}

android {
    namespace = "id.barrakimia.app"
    compileSdk = 36

    defaultConfig {
        applicationId = "id.barrakimia.app"
        minSdk = 23
        targetSdk = 36
        versionCode = 1
        versionName = "1.0.0"
    }

    signingConfigs {
        create("release") {
            val releaseStoreFile = System.getenv("RELEASE_STORE_FILE")
            val releaseStorePassword = System.getenv("RELEASE_STORE_PASSWORD")
            val releaseKeyAlias = System.getenv("RELEASE_KEY_ALIAS")
            val releaseKeyPassword = System.getenv("RELEASE_KEY_PASSWORD")

            if (!releaseStoreFile.isNullOrBlank()) {
                storeFile = file(releaseStoreFile)
            }
            storePassword = releaseStorePassword
            keyAlias = releaseKeyAlias
            keyPassword = releaseKeyPassword
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("release")
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

dependencies {
    implementation("androidx.core:core:1.17.0")
    implementation("com.onesignal:OneSignal:5.9.8")
}
