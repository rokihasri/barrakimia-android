package id.barrakimia.app;

import android.app.Application;

import com.onesignal.Continue;
import com.onesignal.OneSignal;

public class BarraKimiaApplication extends Application {
    public static final String ONESIGNAL_APP_ID = "9fdc5766-32e9-44c3-affb-a80b43da57ca";

    @Override
    public void onCreate() {
        super.onCreate();
        OneSignal.initWithContext(this, ONESIGNAL_APP_ID);
    }

    public void requestPushPermissionAndOptIn() {
        OneSignal.getNotifications().requestPermission(false, Continue.none());
        OneSignal.getUser().getPushSubscription().optIn();
    }
}
