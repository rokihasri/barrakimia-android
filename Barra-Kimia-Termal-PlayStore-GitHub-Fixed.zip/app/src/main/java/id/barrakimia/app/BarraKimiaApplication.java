package id.barrakimia.app;

import android.app.Application;
import android.util.Log;

import com.onesignal.OneSignal;

/**
 * Application-level OneSignal initialization.
 * Push failures must never prevent the WebView app from opening.
 */
public class BarraKimiaApplication extends Application {
    public static final String ONESIGNAL_APP_ID = "9fdc5766-32e9-44c3-affb-a80b43da57ca";
    private static final String TAG = "BarraKimiaOneSignal";

    private volatile boolean oneSignalReady = false;

    @Override
    public void onCreate() {
        super.onCreate();

        try {
            OneSignal.initWithContext(this, ONESIGNAL_APP_ID);
            oneSignalReady = true;
            Log.i(TAG, "OneSignal initialized");
        } catch (Throwable error) {
            // Do not crash the whole app if OneSignal / Google Play Services has a problem.
            oneSignalReady = false;
            Log.e(TAG, "OneSignal initialization failed; app will continue without push", error);
        }
    }

    public boolean isOneSignalReady() {
        return oneSignalReady;
    }

    public void optInPushSafely() {
        if (!oneSignalReady) return;

        try {
            OneSignal.getUser().getPushSubscription().optIn();
            Log.i(TAG, "OneSignal push subscription opt-in requested");
        } catch (Throwable error) {
            Log.e(TAG, "OneSignal opt-in failed; app will continue", error);
        }
    }
}
