# OneSignal ships its own consumer rules. Keep this file for future app-specific rules.
