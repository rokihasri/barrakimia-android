# Barra Kimia Termal - Android WebView

Project Android WebView untuk **https://barrakimiatermal.net**.

## Identitas aplikasi

- Nama: Barra Kimia Termal
- Package: `id.barrakimia.app`
- URL: `https://barrakimiatermal.net`
- minSdk: 23
- targetSdk / compileSdk: 36
- Java: 17
- OneSignal App ID: `9fdc5766-32e9-44c3-affb-a80b43da57ca`

## Fitur

- WebView fullscreen dengan latar putih
- Splash screen putih, logo di tengah, durasi sekitar 1.5 detik
- Upload foto
- Upload dokumen
- Kamera dari file chooser WebView
- OneSignal push notification
- Launcher icon dan ikon notifikasi Barra Kimia Termal
- Workflow GitHub Actions menghasilkan **signed AAB** untuk Play Store dan signed release APK untuk pengujian

## File workflow GitHub

Workflow Play Store berada di:

`.github/workflows/build-playstore.yml`

## GitHub Secrets yang wajib dibuat

Masuk ke repository GitHub:

**Settings -> Secrets and variables -> Actions -> New repository secret**

Tambahkan empat secret berikut:

1. `ANDROID_KEYSTORE_BASE64`
2. `RELEASE_STORE_PASSWORD`
3. `RELEASE_KEY_ALIAS`
4. `RELEASE_KEY_PASSWORD`

Nilai untuk project ini tersedia pada file `github-secrets.txt` yang diberikan **terpisah dari ZIP source**. Jangan commit file tersebut atau file `.jks` ke repository.

## Build di GitHub

1. Extract ZIP project.
2. Upload seluruh isi project ke root repository GitHub. Folder `.github` harus berada di root.
3. Tambahkan 4 GitHub Secrets di atas.
4. Buka tab **Actions**.
5. Pilih **Build Barra Kimia Termal - Play Store Signed**.
6. Klik **Run workflow**.
7. Setelah selesai, download artifact **Barra-Kimia-Termal-PlayStore-AAB**.
8. Upload `app-release.aab` ke Google Play Console.

Build juga otomatis berjalan setiap push ke branch `main`.

## Penting: upload key

File `barra-kimia-termal-upload-key.jks` adalah upload key aplikasi. Simpan file dan password-nya secara permanen di tempat aman. Jangan masukkan ke repository publik/private sebagai file biasa.

Untuk update aplikasi berikutnya, gunakan upload key yang sama. Selain itu, naikkan `versionCode` di `app/build.gradle.kts` sebelum membuat release baru.

## Crash-safe startup update (1.0.1 / versionCode 2)

- OneSignal initialization is isolated so an SDK / Google Play Services failure cannot close the app.
- Android 13+ notification permission uses the native Android runtime permission dialog.
- OneSignal opt-in is executed only after permission is granted and is wrapped safely.
- WebView remains available even if push initialization fails.
