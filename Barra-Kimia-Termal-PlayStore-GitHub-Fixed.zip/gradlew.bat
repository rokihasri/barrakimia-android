\
    @echo off
    setlocal
    set APP_HOME=%~dp0
    set WRAPPER=%APP_HOME%gradle\wrapper\gradle-wrapper.jar
    if not exist "%WRAPPER%" (
      echo Downloading official Gradle 8.13 wrapper...
      powershell -NoProfile -ExecutionPolicy Bypass -Command "Invoke-WebRequest -UseBasicParsing 'https://services.gradle.org/distributions/gradle-8.13-wrapper.jar' -OutFile '%WRAPPER%'"
      if errorlevel 1 exit /b 1
    )
    java %JAVA_OPTS% %GRADLE_OPTS% -classpath "%WRAPPER%" org.gradle.wrapper.GradleWrapperMain %*
    endlocal
