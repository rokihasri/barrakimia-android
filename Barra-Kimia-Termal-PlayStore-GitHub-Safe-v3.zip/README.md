# Barra Kimia Termal Android WebView v1.0.2

- Package: `id.barrakimia.app`
- URL: `https://barrakimiatermal.net`
- Splash: putih, logo tengah, 1.5 detik
- Fullscreen
- Upload foto/dokumen + kamera
- OneSignal App ID: `9fdc5766-32e9-44c3-affb-a80b43da57ca`
- OneSignal Android SDK 5.9.9
- compileSdk / targetSdk 36, minSdk 23
- versionCode 3, versionName 1.0.2

## Perubahan startup-safe
WebView dibuat secara programatik di dalam blok error handler. OneSignal tidak lagi dijalankan dari `Application.onCreate`; push diinisialisasi setelah UI/WebView sudah tampil. Jika provider WebView bermasalah, aplikasi menampilkan pesan error di layar dan tidak langsung menutup.
