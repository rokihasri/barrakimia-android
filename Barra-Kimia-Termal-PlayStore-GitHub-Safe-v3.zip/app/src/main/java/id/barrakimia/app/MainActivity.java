package id.barrakimia.app;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.Gravity;
import android.view.View;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.webkit.CookieManager;
import android.webkit.MimeTypeMap;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.content.FileProvider;

import com.onesignal.OneSignal;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

public class MainActivity extends Activity {
    private static final String HOME_URL = "https://barrakimiatermal.net";
    private static final String ONESIGNAL_APP_ID = "9fdc5766-32e9-44c3-affb-a80b43da57ca";
    private static final int FILE_CHOOSER_REQUEST = 1001;
    private static final int NOTIFICATION_PERMISSION_REQUEST = 1002;

    private WebView webView;
    private ProgressBar progressBar;
    private FrameLayout splashOverlay;
    private FrameLayout webContainer;
    private ValueCallback<Uri[]> filePathCallback;
    private Uri cameraPhotoUri;
    private boolean oneSignalInitialized = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        try {
            getWindow().setStatusBarColor(Color.WHITE);
            getWindow().setNavigationBarColor(Color.WHITE);
        } catch (Throwable ignored) { }

        setContentView(R.layout.activity_main);
        progressBar = findViewById(R.id.progressBar);
        splashOverlay = findViewById(R.id.splashOverlay);
        webContainer = findViewById(R.id.webContainer);

        // Fullscreen is deliberately applied after the content exists and is fully guarded.
        hideSystemBarsSafely();

        try {
            createAndConfigureWebView();

            if (savedInstanceState != null && webView.restoreState(savedInstanceState) != null) {
                splashOverlay.setVisibility(View.GONE);
                scheduleNotificationSetup();
            } else {
                loadFromIntentOrHome(getIntent());
                splashOverlay.postDelayed(() -> {
                    splashOverlay.setVisibility(View.GONE);
                    scheduleNotificationSetup();
                }, 1500L);
            }
        } catch (Throwable error) {
            // Never silently close if Android System WebView or another startup component fails.
            splashOverlay.setVisibility(View.GONE);
            showStartupError(error);
        }
    }

    private void createAndConfigureWebView() {
        webView = new WebView(this);
        webView.setBackgroundColor(Color.WHITE);
        webContainer.addView(webView, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
        ));
        configureWebView();
    }

    private void scheduleNotificationSetup() {
        // Let the WebView become visible first. Push is optional and must never block startup.
        webContainer.postDelayed(this::requestNotificationPermissionSafely, 2000L);
    }

    private void requestNotificationPermissionSafely() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                if (checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                        == PackageManager.PERMISSION_GRANTED) {
                    initOneSignalSafely();
                } else {
                    requestPermissions(
                            new String[]{Manifest.permission.POST_NOTIFICATIONS},
                            NOTIFICATION_PERMISSION_REQUEST
                    );
                }
            } else {
                initOneSignalSafely();
            }
        } catch (Throwable ignored) {
            // Notification permission/push is optional. Keep WebView running.
        }
    }

    private void initOneSignalSafely() {
        if (oneSignalInitialized) return;
        try {
            OneSignal.initWithContext(getApplicationContext(), ONESIGNAL_APP_ID);
            oneSignalInitialized = true;
            try {
                OneSignal.getUser().getPushSubscription().optIn();
            } catch (Throwable ignored) { }
        } catch (Throwable ignored) {
            oneSignalInitialized = false;
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == NOTIFICATION_PERMISSION_REQUEST
                && grantResults.length > 0
                && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            initOneSignalSafely();
        }
    }

    @SuppressWarnings("deprecation")
    private void hideSystemBarsSafely() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                WindowInsetsController controller = getWindow().getInsetsController();
                if (controller != null) {
                    controller.hide(WindowInsets.Type.statusBars() | WindowInsets.Type.navigationBars());
                    controller.setSystemBarsBehavior(
                            WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                    );
                }
            } else {
                getWindow().getDecorView().setSystemUiVisibility(
                        View.SYSTEM_UI_FLAG_FULLSCREEN
                                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                                | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                );
            }
        } catch (Throwable ignored) { }
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) hideSystemBarsSafely();
    }

    @SuppressLint("SetJavaScriptEnabled")
    private void configureWebView() {
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowContentAccess(true);
        settings.setAllowFileAccess(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setSupportMultipleWindows(false);
        settings.setJavaScriptCanOpenWindowsAutomatically(true);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        }

        try {
            String ua = settings.getUserAgentString();
            if (ua != null && !ua.isEmpty()) {
                settings.setUserAgentString(ua + " BarraKimiaTermalAndroid/1.0.2");
            }
        } catch (Throwable ignored) { }

        try {
            CookieManager cookieManager = CookieManager.getInstance();
            cookieManager.setAcceptCookie(true);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                cookieManager.setAcceptThirdPartyCookies(webView, true);
            }
        } catch (Throwable ignored) { }

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return handleUrl(request.getUrl());
            }

            @Override
            @SuppressWarnings("deprecation")
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return handleUrl(Uri.parse(url));
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView view, int newProgress) {
                if (progressBar != null) {
                    progressBar.setProgress(newProgress);
                    progressBar.setVisibility(newProgress >= 100 ? View.GONE : View.VISIBLE);
                }
            }

            @Override
            public boolean onShowFileChooser(
                    WebView view,
                    ValueCallback<Uri[]> newCallback,
                    FileChooserParams fileChooserParams) {
                if (filePathCallback != null) {
                    filePathCallback.onReceiveValue(null);
                }
                filePathCallback = newCallback;
                return openFileChooser(fileChooserParams);
            }
        });

        webView.setDownloadListener((url, userAgent, contentDisposition, mimeType, contentLength) -> {
            try {
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
            } catch (Throwable e) {
                Toast.makeText(this, "Tidak ada aplikasi untuk membuka unduhan.", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void showStartupError(Throwable error) {
        if (webContainer == null) return;
        webContainer.removeAllViews();
        TextView message = new TextView(this);
        message.setTextColor(Color.BLACK);
        message.setBackgroundColor(Color.WHITE);
        message.setGravity(Gravity.CENTER);
        message.setPadding(48, 48, 48, 48);
        message.setTextSize(15f);
        String type = error == null ? "Unknown" : error.getClass().getSimpleName();
        String detail = error == null || error.getMessage() == null ? "" : "\n\n" + error.getMessage();
        message.setText("Barra Kimia Termal tidak dapat membuka Android System WebView.\n\nError: " + type + detail
                + "\n\nPastikan Chrome / Android System WebView aktif dan sudah diperbarui.");
        webContainer.addView(message, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
        ));
    }

    private boolean openFileChooser(WebChromeClient.FileChooserParams params) {
        try {
            Intent fileIntent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            fileIntent.addCategory(Intent.CATEGORY_OPENABLE);

            String[] mimeTypes = normalizedMimeTypes(params.getAcceptTypes());
            if (mimeTypes.length == 0) {
                fileIntent.setType("*/*");
            } else if (mimeTypes.length == 1) {
                fileIntent.setType(mimeTypes[0]);
            } else {
                fileIntent.setType("*/*");
                fileIntent.putExtra(Intent.EXTRA_MIME_TYPES, mimeTypes);
            }

            if (params.getMode() == WebChromeClient.FileChooserParams.MODE_OPEN_MULTIPLE) {
                fileIntent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
            }

            Intent cameraIntent = createCameraIntent();
            boolean acceptsImage = acceptsImages(mimeTypes);

            if (params.isCaptureEnabled() && acceptsImage && cameraIntent != null) {
                startActivityForResult(cameraIntent, FILE_CHOOSER_REQUEST);
                return true;
            }

            Intent chooser = new Intent(Intent.ACTION_CHOOSER);
            chooser.putExtra(Intent.EXTRA_INTENT, fileIntent);
            chooser.putExtra(Intent.EXTRA_TITLE, "Pilih foto atau dokumen");
            if (acceptsImage && cameraIntent != null) {
                chooser.putExtra(Intent.EXTRA_INITIAL_INTENTS, new Intent[]{cameraIntent});
            }
            startActivityForResult(chooser, FILE_CHOOSER_REQUEST);
            return true;
        } catch (ActivityNotFoundException e) {
            finishFileChooser(null);
            Toast.makeText(this, "Pemilih file tidak tersedia.", Toast.LENGTH_SHORT).show();
            return false;
        } catch (Throwable e) {
            finishFileChooser(null);
            return false;
        }
    }

    private Intent createCameraIntent() {
        try {
            Intent camera = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            if (camera.resolveActivity(getPackageManager()) == null) return null;

            File directory = new File(getCacheDir(), "camera");
            if (!directory.exists() && !directory.mkdirs()) return null;
            String stamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date());
            File photo = File.createTempFile("BKT_" + stamp + "_", ".jpg", directory);
            cameraPhotoUri = FileProvider.getUriForFile(
                    this,
                    getPackageName() + ".fileprovider",
                    photo
            );
            camera.putExtra(MediaStore.EXTRA_OUTPUT, cameraPhotoUri);
            camera.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
            camera.setClipData(ClipData.newRawUri("camera_photo", cameraPhotoUri));
            return camera;
        } catch (IOException e) {
            cameraPhotoUri = null;
            return null;
        } catch (Throwable e) {
            cameraPhotoUri = null;
            return null;
        }
    }

    private String[] normalizedMimeTypes(String[] acceptTypes) {
        Set<String> out = new LinkedHashSet<>();
        if (acceptTypes != null) {
            for (String raw : acceptTypes) {
                if (raw == null) continue;
                String[] parts = raw.split(",");
                for (String part : parts) {
                    String item = part.trim().toLowerCase(Locale.US);
                    if (item.isEmpty()) continue;
                    if (item.startsWith(".")) {
                        String mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(item.substring(1));
                        if (mime != null) out.add(mime);
                    } else if (item.contains("/")) {
                        out.add(item);
                    }
                }
            }
        }
        return out.toArray(new String[0]);
    }

    private boolean acceptsImages(String[] mimeTypes) {
        if (mimeTypes.length == 0) return true;
        for (String type : mimeTypes) {
            if ("*/*".equals(type) || type.startsWith("image/")) return true;
        }
        return false;
    }

    @Override
    @SuppressWarnings("deprecation")
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != FILE_CHOOSER_REQUEST || filePathCallback == null) return;

        if (resultCode != RESULT_OK) {
            finishFileChooser(null);
            return;
        }

        List<Uri> results = new ArrayList<>();
        if (data != null) {
            ClipData clipData = data.getClipData();
            if (clipData != null) {
                for (int i = 0; i < clipData.getItemCount(); i++) {
                    Uri uri = clipData.getItemAt(i).getUri();
                    if (uri != null) results.add(uri);
                }
            } else if (data.getData() != null) {
                results.add(data.getData());
            }
        }

        if (results.isEmpty() && cameraPhotoUri != null) results.add(cameraPhotoUri);
        finishFileChooser(results.isEmpty() ? null : results.toArray(new Uri[0]));
    }

    private void finishFileChooser(Uri[] results) {
        if (filePathCallback != null) filePathCallback.onReceiveValue(results);
        filePathCallback = null;
        cameraPhotoUri = null;
    }

    private boolean handleUrl(Uri uri) {
        if (uri == null) return false;
        String scheme = uri.getScheme() == null ? "" : uri.getScheme().toLowerCase(Locale.US);
        String host = uri.getHost() == null ? "" : uri.getHost().toLowerCase(Locale.US);

        if (("https".equals(scheme) || "http".equals(scheme)) && isInternalHost(host)) {
            return false;
        }

        if ("intent".equals(scheme)) {
            try {
                Intent intent = Intent.parseUri(uri.toString(), Intent.URI_INTENT_SCHEME);
                if (intent.resolveActivity(getPackageManager()) != null) {
                    startActivity(intent);
                } else {
                    String fallback = intent.getStringExtra("browser_fallback_url");
                    if (fallback != null) startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(fallback)));
                }
            } catch (Throwable ignored) { }
            return true;
        }

        try {
            startActivity(new Intent(Intent.ACTION_VIEW, uri));
            return true;
        } catch (Throwable e) {
            return false;
        }
    }

    private boolean isInternalHost(String host) {
        return host.equals("barrakimiatermal.net") || host.endsWith(".barrakimiatermal.net");
    }

    private void loadFromIntentOrHome(Intent intent) {
        Uri data = intent == null ? null : intent.getData();
        if (data != null && "https".equalsIgnoreCase(data.getScheme())
                && isInternalHost(data.getHost() == null ? "" : data.getHost())) {
            webView.loadUrl(data.toString());
        } else {
            webView.loadUrl(HOME_URL);
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        if (webView != null) loadFromIntentOrHome(intent);
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        if (webView != null) webView.saveState(outState);
        super.onSaveInstanceState(outState);
    }

    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        if (filePathCallback != null) {
            filePathCallback.onReceiveValue(null);
            filePathCallback = null;
        }
        if (webView != null) {
            try {
                webView.stopLoading();
                webView.setWebChromeClient(null);
                webView.setWebViewClient(null);
                webView.destroy();
            } catch (Throwable ignored) { }
        }
        super.onDestroy();
    }
}
